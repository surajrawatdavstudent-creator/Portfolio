import { ArrowRight, Image as ImageIcon, CodeXml, Plus } from 'lucide-react';
import { portfolio, type Media, type Project } from '@/content/portfolio';
import { NewTabLink } from './site-link';
export function Portrait({compact = false}: {compact?: boolean}) {
 return <figure className={`portrait-frame ${compact ? 'portrait-compact' : ''}`}>
 <div className="portrait-label"><span>01 / THE BUILDER</span><Plus size={16} aria-hidden="true"/></div>
 {portfolio.portrait ? <img src={portfolio.portrait.src} alt={portfolio.portrait.alt} width={portfolio.portrait.width} height={portfolio.portrait.height} className="real-portrait" fetchPriority={compact ? 'auto' : 'high'} loading={compact ? 'lazy' : 'eager'}/> : <div className="portrait-placeholder"><span className="portrait-monogram" aria-hidden="true">SR<span>_</span></span><span className="placeholder-caption"><ImageIcon size={17} aria-hidden="true"/>{portfolio.copy.portraitPlaceholder}</span></div>}
 <figcaption><span>{portfolio.name}<small>{portfolio.role}</small></span><Plus className="portrait-corner" size={19} aria-hidden="true"/></figcaption></figure>;
}
export function ProjectPhoto({project, large = false}: {project: Project; large?: boolean}) {
 return project.photo ? <figure className={`project-photo real-photo ${large ? 'photo-large' : ''}`}><img src={project.photo.src} alt={project.photo.alt} width={project.photo.width} height={project.photo.height} loading="lazy"/>{large && project.photo.caption && <figcaption>{project.photo.caption}</figcaption>}</figure> : <div className={`project-photo technical-placeholder ${large ? 'photo-large' : ''}`}><div className="drawing-corner top-left"/><div className="drawing-corner bottom-right"/><div className="photo-placeholder-inner"><ImageIcon size={27} strokeWidth={1.25} aria-hidden="true"/><span>{portfolio.copy.photoPlaceholder}</span></div><span className="photo-reference" aria-hidden="true">{project.slug.split('-').map(s=>s[0]).join('').toUpperCase()} / IMAGE PENDING</span></div>;
}
export function ProjectCard({project, index}: {project: Project; index: number}) {
 return <article className="project-card"><ProjectPhoto project={project}/><div className="project-card-body">
 <div className="project-card-meta"><span className="mono">PROJECT {String(index+1).padStart(2,'0')}</span><span className={`status ${project.status ? project.status.toLowerCase().replace(' ','-') : 'unconfirmed'}`}>{project.status || 'Status to confirm'}</span></div>
 <h3><a href={`/projects/${project.slug}`}>{project.name}<ArrowRight size={21} aria-hidden="true"/></a></h3><p>{project.summary || portfolio.copy.projectSummaryPlaceholder}</p>
 {project.tags.length>0 && <ul className="tag-list">{project.tags.map(tag=><li key={tag}>{tag}</li>)}</ul>}
 <a href={`/projects/${project.slug}`} className="project-link" aria-label={`View project: ${project.name}`}>View Project<ArrowRight size={16} aria-hidden="true"/></a></div></article>;
}
export function PageHeading({number,eyebrow,title,description}: {number:string;eyebrow:string;title:string;description:string}) {
 return <div className="page-heading"><div className="eyebrow"><span>{number}</span><span className="eyebrow-line"/>{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>;
}
export function PreviewNote({children}: {children: React.ReactNode}) { return <aside className="preview-note"><span className="note-marker">PREVIEW</span><p>{children}</p></aside>; }
export function MissingContent({children}: {children: React.ReactNode}) { return <p className="missing-content">{children}</p>; }
export function MediaFigure({media}: {media: Media}) { return <figure className="media-figure"><img src={media.src} alt={media.alt} width={media.width} height={media.height} loading="lazy"/>{media.caption && <figcaption>{media.caption}</figcaption>}</figure>; }
export function GitHubLink({className = ''}: {className?: string}) { return portfolio.github ? <NewTabLink href={portfolio.github} className={`github-link ${className}`}><CodeXml size={19} aria-hidden="true"/>GitHub</NewTabLink> : portfolio.previewMode ? <span className={`github-placeholder ${className}`}><CodeXml size={18} aria-hidden="true"/>{portfolio.copy.githubPlaceholder}</span> : null; }
export function SiteFooter() {
 return <footer className="site-footer"><div className="container"><div className="footer-main"><div><a href="/" className="footer-name">{portfolio.name}<span>.</span></a><p>{portfolio.copy.footer}</p></div><nav aria-label="Footer navigation"><NewTabLink href="/projects">Projects</NewTabLink><NewTabLink href="/about">About Me</NewTabLink><NewTabLink href="/contact">Contact</NewTabLink>{portfolio.github && <GitHubLink/>}</nav></div><div className="footer-bottom"><span>© {new Date().getFullYear()} {portfolio.name}</span><span>Student & aspiring engineer</span><span>↗ Links marked with an arrow open a new tab.</span></div></div></footer>;
}

import { ArrowUpRight } from 'lucide-react';
import type { ReactNode } from 'react';
import { safeUrl } from '@/content/portfolio';
export function NewTabLink({href, children, className = '', label}: {href: string; children: ReactNode; className?: string; label?: string}) {
 const url = safeUrl(href);
 if (!url) return null;
 return <a href={url} target="_blank" rel="noopener noreferrer" className={className} aria-label={label ? `${label} (opens in a new tab)` : undefined}>
 {children}<ArrowUpRight size={16} aria-hidden="true" className="external-icon"/>{!label && <span className="sr-only"> (opens in a new tab)</span>}</a>;
}

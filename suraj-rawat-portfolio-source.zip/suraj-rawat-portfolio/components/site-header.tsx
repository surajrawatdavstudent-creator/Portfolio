'use client';
import { useState } from 'react';
import { usePathname } from 'next/navigation';
import { Menu } from 'lucide-react';
import { Sheet, SheetTrigger, SheetContent, SheetTitle, SheetDescription, SheetClose } from '@/components/ui/sheet';
import { portfolio } from '@/content/portfolio';
const navigation = [{label:'Home',href:'/'},{label:'About Me',href:'/about'},{label:'Skills',href:'/skills'},{label:'Projects',href:'/projects'},{label:'Qualifications',href:'/qualifications'},{label:'Contact',href:'/contact'}];
export function SiteHeader() {
 const pathname = usePathname();
 const [open, setOpen] = useState(false);
 const navItems = (mobile = false) => navigation.map(({label,href}) => {
  const active = href === '/' ? pathname === '/' : pathname.startsWith(href);
  return <li key={href}><a href={href} target={href==='/' ? undefined : '_blank'} rel={href==='/' ? undefined : 'noopener noreferrer'} aria-current={active ? 'page' : undefined} className={active ? 'nav-active' : ''} onClick={() => mobile && setOpen(false)}>
  {label}{href !== '/' && <><span className="nav-arrow" aria-hidden="true">↗</span><span className="sr-only"> (opens in a new tab)</span></>}</a></li>;
 });
 return <header className="site-header"><div className="container header-inner">
 <a href="/" className="brand" aria-label={`${portfolio.name} — Home`}><span className="brand-mark">{portfolio.initials}<span className="brand-dot">.</span></span><span>{portfolio.name}</span></a>
 <nav aria-label="Main navigation" className="desktop-nav"><ul>{navItems()}</ul></nav>
 <div className="mobile-nav"><Sheet open={open} onOpenChange={setOpen}>
 <SheetTrigger asChild><button className="menu-button" aria-label="Open navigation menu"><Menu size={22}/><span>Menu</span></button></SheetTrigger>
 <SheetContent className="portfolio-menu" side="right" showCloseButton={false}>
 <div className="menu-top"><SheetTitle>{portfolio.name}</SheetTitle><SheetClose className="menu-close">Close <span aria-hidden="true">×</span></SheetClose></div>
 <SheetDescription>Explore the portfolio. Links marked ↗ open a new tab.</SheetDescription>
 <nav aria-label="Mobile navigation"><ul>{navItems(true)}</ul></nav>
 </SheetContent></Sheet></div></div></header>;
}

import type { Metadata } from 'next';
import { Mail } from 'lucide-react';
import { portfolio } from '@/content/portfolio';
import { PageHeading } from '@/components/portfolio-ui';
import { NewTabLink } from '@/components/site-link';
export const metadata: Metadata = {title:'Contact',description:'Connect with Suraj Rawat about engineering projects, learning opportunities, and collaborations through approved public contact links.'};
export default function ContactPage() {
 const email=portfolio.email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(portfolio.email) ? portfolio.email : null;
 return <div className="container page-container"><PageHeading number="05" eyebrow="LET’S CONNECT" title="Start a conversation." description={portfolio.copy.contactIntro}/>
 <div className="contact-grid"><section className="contact-card"><Mail size={30} strokeWidth={1.4} aria-hidden="true"/><h2>Ideas begin with<br/>a conversation.</h2><p>{email ? 'For project discussions and learning opportunities, you can reach me by email.' : portfolio.copy.contactEmpty}</p>{email ? <a className="contact-email" href={`mailto:${email}`}>{email}</a> : <p className="eyebrow" style={{marginTop:26}}>PUBLIC EMAIL TO BE ADDED</p>}</section>
 <div className="contact-links"><h2>Find me online</h2>{portfolio.github ? <NewTabLink href={portfolio.github} className="text-link">GitHub</NewTabLink> : portfolio.previewMode && <div className="contact-placeholder"><span>GitHub</span><small>Profile link to be added</small></div>}
 {portfolio.linkedin && <NewTabLink href={portfolio.linkedin} className="text-link">LinkedIn</NewTabLink>}
 {portfolio.professionalLinks.map(link=><NewTabLink key={link.url} href={link.url} className="text-link">{link.label}</NewTabLink>)}
 <div className="contact-context"><h3>What I’m interested in</h3><p>Robotics, mechatronics, automation, and embedded systems. I welcome conversations about practical projects and opportunities to keep learning.</p></div></div></div></div>;
}
import type { Metadata } from 'next';
import { portfolio } from '@/content/portfolio';
import { PageHeading, Portrait, MissingContent } from '@/components/portfolio-ui';
import { NewTabLink } from '@/components/site-link';
export const metadata: Metadata = {title:'About Me',description:'Meet Suraj Rawat, a student learning about robotics, automation, and embedded systems through practical projects.'};
export default function AboutPage() {
 return <div className="container page-container"><PageHeading number="01" eyebrow="THE PERSON BEHIND THE PROJECTS" title="About me." description="A student, a curious mind, and a growing interest in engineering."/>
 <div className="about-grid"><div className="prose"><p className="intro-large">{portfolio.about.introduction}</p>{portfolio.about.paragraphs.map(p=><p key={p}>{p}</p>)}<NewTabLink href="/projects" className="text-link">Explore my project notebook</NewTabLink></div><Portrait compact/></div>
 <section className="content-section"><h2>Why these fields interest me</h2>{portfolio.about.motivation ? <p>{portfolio.about.motivation}</p> : <MissingContent>Personal motivation to be added: what first drew me to robotics, automation, and embedded systems.</MissingContent>}</section>
 <section className="content-section"><h2>How I approach learning</h2><div className="process-grid">{portfolio.about.process.map((step,index)=><div className="process-step" key={step.title}><span className="mono">0{index+1} /</span><h3>{step.title}</h3><p>{step.text}</p></div>)}</div></section>
 <div className="two-column"><section className="content-section"><h2>What I’m learning now</h2>{portfolio.about.priorities.length ? <ul>{portfolio.about.priorities.map(p=><li key={p}>{p}</li>)}</ul> : <MissingContent>My current learning priorities will be added after confirmation.</MissingContent>}</section><section className="content-section"><h2>Looking ahead</h2><p>{portfolio.about.future}</p><NewTabLink href="/skills" className="text-link">My skills & learning</NewTabLink></section></div></div>;
}
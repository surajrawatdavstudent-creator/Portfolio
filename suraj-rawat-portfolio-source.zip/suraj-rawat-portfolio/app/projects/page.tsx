import type { Metadata } from 'next';
import { portfolio, visibleProjects } from '@/content/portfolio';
import { PageHeading, PreviewNote, ProjectCard } from '@/components/portfolio-ui';
import { NewTabLink } from '@/components/site-link';
export const metadata: Metadata = {title:'Projects',description:'Explore Suraj Rawat’s project notebook, with individual pages for hardware, robotics, and embedded systems projects.'};
export default function ProjectsPage() {
 return <div className="container page-container"><PageHeading number="03" eyebrow="THE PROJECT NOTEBOOK" title="Built to learn." description={portfolio.copy.projectsIntro}/>
 {portfolio.previewMode && <PreviewNote>{portfolio.copy.projectPreview}</PreviewNote>}
 <h2 className="sr-only">Hardware project gallery</h2><div className="project-grid project-gallery">{visibleProjects().map((project,index)=><ProjectCard key={project.slug} project={project} index={index}/>)}</div>
 {portfolio.softwareProjects.length>0 && <section className="content-section"><h2>Software & websites</h2><div className="skills-grid">{portfolio.softwareProjects.map(project=><article className="skill-category" key={project.name}><h3>{project.name}</h3><p>{project.description}</p>{project.links.map(link=><NewTabLink key={link.url} href={link.url} className="text-link">{link.label}</NewTabLink>)}</article>)}</div></section>}</div>;
}
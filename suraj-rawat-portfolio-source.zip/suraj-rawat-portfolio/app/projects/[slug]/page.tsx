import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { ArrowLeft } from 'lucide-react';
import { portfolio, visibleProjects } from '@/content/portfolio';
import { ProjectPhoto, PreviewNote, MissingContent, MediaFigure } from '@/components/portfolio-ui';
import { NewTabLink } from '@/components/site-link';
type Props={params:Promise<{slug:string}>};
export async function generateMetadata({params}:Props):Promise<Metadata>{
 const {slug}=await params; const project=visibleProjects().find(p=>p.slug===slug);
 return {title:project?.name || 'Project not found',description:project?.summary || (project ? `Project notebook for ${project.name}: purpose, components, personal contribution, evidence, and lessons. Content awaiting confirmation.` : 'This project could not be found.')};
}
export function generateStaticParams(){return visibleProjects().map(p=>({slug:p.slug}));}
const index=[['overview','Overview & purpose'],['build','Components & operation'],['contribution','My contribution'],['results','Results & evidence'],['learning','Lessons & next steps'],['media','Photos & links']];
function Field({text,placeholder}:{text:string|null;placeholder:string}){return text ? <p>{text}</p> : <MissingContent>{placeholder}</MissingContent>;}
export default async function ProjectPage({params}:Props) {
 const {slug}=await params;const project=visibleProjects().find(p=>p.slug===slug);if(!project) notFound();
 return <div className="container page-container">
 <a href="/projects" className="breadcrumb"><ArrowLeft size={16} aria-hidden="true"/>Back to projects</a>
 <header className="detail-header"><div className="eyebrow">PROJECT NOTEBOOK / {project.category}</div><h1>{project.name}</h1><div className="detail-meta"><span className="status">{project.status || 'Status to confirm'}</span>{!project.confirmed && <span className="mono">DRAFT PROJECT ENTRY</span>}</div>{project.summary && <p className="detail-intro">{project.summary}</p>}</header>
 {!project.confirmed && <PreviewNote>This is a project-page preview. Build details, my contribution, tutorial sources, and results have not yet been supplied.</PreviewNote>}
 <ProjectPhoto project={project} large/>
 <div className="detail-layout"><aside className="project-index"><h2>IN THIS PROJECT</h2><nav aria-label="Project page contents">{index.map(([id,label])=><a key={id} href={`#${id}`}>{label}</a>)}</nav></aside>
 <div><section className="detail-section" id="overview"><h2>01 / Overview & purpose</h2><Field text={project.overview} placeholder="A confirmed description of the project and its purpose will appear here."/><h3>The problem or learning goal</h3><Field text={project.goal} placeholder="The problem I set out to solve, or the concept I wanted to understand, is still to be documented."/></section>
 <section className="detail-section" id="build"><h2>02 / Inside the build</h2><h3>Components & software</h3>{project.components.length || project.software.length ? <div className="two-column">{project.components.length>0 && <div><h4>Hardware</h4><ul className="content-list">{project.components.map(item=><li key={item}>{item}</li>)}</ul></div>}{project.software.length>0 && <div><h4>Software</h4><ul className="content-list">{project.software.map(item=><li key={item}>{item}</li>)}</ul></div>}</div> : <MissingContent>The actual components, connections, and software will be added from the build notes.</MissingContent>}
 <h3>How it works</h3><Field text={project.operation} placeholder="The sequence of inputs, processing, and outputs is awaiting confirmation."/>
 {project.diagram && <><h3>Circuit diagram or system architecture</h3><MediaFigure media={project.diagram}/></>}</section>
 <section className="detail-section" id="contribution"><h2>03 / My contribution</h2><Field text={project.contribution} placeholder="The parts I built, wrote, adapted, or improved will be explained here."/>
 {project.tutorial && <div className="content-section"><h3>Tutorial credit</h3><NewTabLink className="text-link" href={project.tutorial.url}>{project.tutorial.title}</NewTabLink><p>{project.tutorial.adaptation}</p></div>}
 <h3>Challenges & troubleshooting</h3><Field text={project.challenges} placeholder="A real challenge, the steps I tried, and how I addressed it will be documented here."/></section>
 <section className="detail-section" id="results"><h2>04 / Results & evidence</h2><Field text={project.results} placeholder="No results or performance claims have been added. Observations will be supported by real photos, recordings, logs, or measurements."/>
 {project.evidence.length>0 && <ul>{project.evidence.map(link=><li key={link.url}><NewTabLink className="text-link" href={link.url}>{link.label}</NewTabLink></li>)}</ul>}</section>
 <section className="detail-section" id="learning"><h2>05 / What I learned</h2><Field text={project.learning} placeholder="My takeaways from the actual building and testing process will appear here."/><h3>Possible future improvements</h3><Field text={project.improvements} placeholder="Next steps will be added after the current build and its limitations are confirmed."/></section>
 <section className="detail-section" id="media"><h2>06 / Photos & project links</h2>{project.gallery.length>0 ? <div className="media-gallery">{project.gallery.map(media=><MediaFigure key={media.src} media={media}/>)}</div> : <MissingContent>Real project photographs have not been supplied yet.</MissingContent>}
 {project.video && <figure className="media-figure"><video controls preload="metadata" playsInline poster={project.video.poster} aria-label={project.video.caption}><source src={project.video.src}/><p>Your browser does not support this video.</p></video><figcaption>{project.video.caption}</figcaption></figure>}
 {(project.repository || project.liveDemo) && <div className="detail-links">{project.repository && <NewTabLink href={project.repository} className="text-link">GitHub repository</NewTabLink>}{project.liveDemo && <NewTabLink href={project.liveDemo} className="text-link">Live demonstration</NewTabLink>}</div>}</section>
 </div></div></div>;
}
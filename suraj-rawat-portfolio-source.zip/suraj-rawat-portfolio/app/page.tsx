import type { Metadata } from 'next';
import { Cpu, Cog, Workflow, CircuitBoard } from 'lucide-react';
import { portfolio, visibleProjects } from '@/content/portfolio';
import { Portrait, ProjectCard, GitHubLink } from '@/components/portfolio-ui';
import { NewTabLink } from '@/components/site-link';
export const metadata: Metadata = {title: {absolute:'Suraj Rawat | Robotics & Embedded Systems Portfolio'}, description: portfolio.introduction};
const interestIcons = [Cpu,Cog,Workflow,CircuitBoard];
export default function Home() {
 const featured = visibleProjects().filter(project=>project.featured).slice(0,3);
 return <>
 <section className="home-hero"><div className="container hero-grid"><div className="hero-copy">
 <div className="eyebrow light"><span className="eyebrow-line"/>{portfolio.copy.homeEyebrow}</div>
 <p className="hero-welcome">Hello, I’m <strong>{portfolio.name}.</strong></p>
 <h1>{portfolio.headline.includes(portfolio.headlineAccent) ? <>{portfolio.headline.split(portfolio.headlineAccent)[0]}<span>{portfolio.headlineAccent}</span>{portfolio.headline.split(portfolio.headlineAccent).slice(1).join(portfolio.headlineAccent)}</> : portfolio.headline}</h1>
 <p className="hero-intro">{portfolio.introduction}</p>
 <div className="hero-actions"><NewTabLink href="/projects" className="button button-teal">Explore My Projects</NewTabLink><NewTabLink href="/about" className="button button-outline">About Me</NewTabLink></div><GitHubLink/>
 </div><Portrait/></div><div className="container hero-bottom"><span>CODE. CONNECT. BUILD. LEARN.</span><span>Robotics / Mechatronics / Automation</span></div></section>
 {featured.length>0 && <section className="section featured-section"><div className="container"><div className="section-heading"><div><div className="eyebrow"><span>01</span><span className="eyebrow-line"/>THE PROJECT NOTEBOOK</div><h2>Learning, put into practice.</h2></div><NewTabLink href="/projects" className="text-link">All projects</NewTabLink></div>{portfolio.previewMode && <p className="section-note">Project previews · Build details, status, and photos awaiting confirmation.</p>}<div className="project-grid">{featured.map((project,index)=><ProjectCard key={project.slug} project={project} index={index}/>)}</div></div></section>}
 <section className="section interest-section"><div className="container"><div className="section-heading"><div><div className="eyebrow"><span>02</span><span className="eyebrow-line"/>WHAT I’M EXPLORING</div><h2>Where my curiosity takes me.</h2></div><NewTabLink href="/skills" className="text-link">Explore my skills</NewTabLink></div><div className="interest-grid">{portfolio.interests.map((interest,index)=>{const Icon=interestIcons[index];return <div className="interest-item" key={interest.name}><Icon size={26} strokeWidth={1.5} aria-hidden="true"/><h3>{interest.name}</h3><p>{interest.description}</p></div>})}</div></div></section>
 </>;
}

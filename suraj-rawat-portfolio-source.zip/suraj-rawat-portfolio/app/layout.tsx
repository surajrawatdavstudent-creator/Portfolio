import type { Metadata } from 'next';
import './globals.css';
import { SiteHeader } from '@/components/site-header';
import { SiteFooter } from '@/components/portfolio-ui';
export const metadata: Metadata = {
 title: {default:'Suraj Rawat | Engineering Portfolio',template:'%s | Suraj Rawat'},
 description:'The projects, interests, and learning journey of Suraj Rawat, a student exploring robotics, mechatronics, automation, and embedded systems.',
 robots:{index:false,follow:false},
 icons:{icon:'/favicon.svg',shortcut:'/favicon.svg'},
};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>) {
 return <html lang="en"><body><a className="skip-link" href="#main-content">Skip to content</a><SiteHeader/><main id="main-content" tabIndex={-1}>{children}</main><SiteFooter/></body></html>;
}

import type { Metadata } from 'next';
import { portfolio } from '@/content/portfolio';
import { PageHeading, PreviewNote } from '@/components/portfolio-ui';
export const metadata: Metadata = {title:'Skills',description:'Programming, hardware, tools, and practical engineering skills in Suraj Rawat’s portfolio, with experience distinguished from current learning.'};
export default function SkillsPage() {
 return <div className="container page-container"><PageHeading number="02" eyebrow="TOOLS & LEARNING" title="Skills, in context." description={portfolio.copy.skillsIntro}/>
 {portfolio.previewMode && <PreviewNote>{portfolio.copy.skillsPreview}</PreviewNote>}
 <div className="skills-grid">{portfolio.skillCategories.map((category,index)=><section className="skill-category" key={category.name}><div className="eyebrow" style={{marginBottom:15}}>0{index+1} /</div><h2>{category.name}</h2><p>{category.description}</p>
 {(['Used','Learning','To confirm'] as const).map(state=>{const skills=category.skills.filter(s=>s.state===state && (portfolio.previewMode || state!=='To confirm'));return skills.length>0 ? <div className="skill-group" key={state}><h3>{state==='Used'?'Used in projects':state==='Learning'?'Currently learning':'Awaiting confirmation'}</h3><ul>{skills.map(skill=><li className="skill-row" key={skill.name}><span className="skill-name">{skill.name}</span>{skill.example && <p>{skill.example}</p>}{skill.projectSlug && <a className="text-link" href={`/projects/${skill.projectSlug}`}>See project example</a>}</li>)}</ul></div> : null})}
 </section>)}</div>
 <section className="content-section"><h2>Experience should have an example.</h2><p>As the project notebook grows, each confirmed skill can be connected to the build where I used it or the topic I’m currently learning.</p></section></div>;
}
import type { Metadata } from 'next';
export const metadata: Metadata = {title:'Page not found',description:'This page could not be found. Return to Suraj Rawat’s portfolio or browse the project notebook.'};
export default function NotFound() {return <div className="container empty-page"><p className="error-number">404</p><h1>This connection leads nowhere.</h1><p>The page may have moved, or the address may be incomplete.</p><a href="/" className="button button-navy">Back to Home</a><a href="/projects" className="text-link" style={{marginLeft:16}}>Browse projects</a></div>;}

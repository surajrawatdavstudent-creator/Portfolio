# Editing Suraj’s portfolio

The site uses React and TypeScript with file-based pages through Vinext. It serves complete pages on direct visits and refreshes. There is no project database, contact service, or custom account system.

## Where to edit

- `content/portfolio.ts`: all personal information, skills, projects, education, credentials, contact details, and main copy.
- `app/`: page layouts and short interface labels.
- `components/`: shared header, footer, project cards, media placeholders, and links.
- `app/globals.css`: colors, typography, spacing, and responsive styles.
- `public/`: approved images, PDFs, and videos. A file at `public/images/portrait.webp` is referenced as `/images/portrait.webp`.
- `docs/QA.md`: checks performed and remaining limitations.

## Run locally

Use Node 22.13 or newer. Install with `npm ci`, then run `npm run dev`. Follow the URL printed by the development server. Run `npm run build` for the deployment build. In this managed environment, use the documented Sites build/preview controls.

## Replace photos

Set `portrait` or a project’s `photo` to an object like this (replace dimensions with the real image’s dimensions):

```ts
{
 src: '/images/your-photo.webp',
 alt: 'Describe the actual photograph clearly.',
 width: 1200,
 height: 1500,
 caption: 'Optional factual caption'
}
```

Use your own photographs. Compress large images to WebP or JPEG and remove unnecessary location metadata. Supply real width and height to reserve space. Images use containment or natural height to preserve proportions, without stretching. Project photos and certificate previews load lazily; the main portrait loads immediately. Keep an uncropped original separately if you want it for other uses.

## Complete a project

The four proposed entries are previews with `confirmed: false` and `status: null`. Null is deliberately rendered as “Status to confirm”; it is not treated as Planned or Completed.

Replace or add entries in `projects`. Each needs a unique lowercase, hyphenated `slug`. Its page is automatically available at `/projects/your-slug`. Set `featured: true` for the three projects to show on Home.

Fill `summary`, `overview`, `goal`, `components`, `software`, `operation`, `contribution`, `challenges`, `results`, `learning`, and `improvements` with your real account. Use `tags` for actual technologies. Confirm status as exactly `Completed`, `In Progress`, or `Planned`; then set `confirmed: true`.

Optional fields:
- `diagram`: a Media object for a supplied circuit diagram or architecture.
- `gallery`: Media objects for real project photographs.
- `video`: a local video path, optional poster, and descriptive caption.
- `evidence`: labeled links supporting the reported results.
- `repository` and `liveDemo`: real working URLs.
- `tutorial`: source title, source URL, and an honest description of what you adapted.

Do not describe a tutorial’s result as your own. Separate your contribution from the original instructions. Record what you observed, including limits and unresolved problems.

Use `softwareProjects` for additional websites and programming projects. This section is hidden while empty.

## Skills and biography

Each skill has a state: `Used`, `Learning`, or `To confirm`. Used and Learning appear in clearly labeled groups. Add one brief factual `example` and, where useful, a valid `projectSlug`. C/C++ and CAD were deliberately omitted until you confirm them.

Add your personal motivation to `about.motivation`, present learning goals to `about.priorities`, and revise the introductory copy in your own words.

## Education, certificates, and CV

Add education entries with period, qualification/course, institution, and description. Only add `grade` if you want it published.

For credentials, use the exact title and issuer printed on the certificate. Set `confirmed: true` after checking the file. A certificate preview or verification link appears only when `displayApproved: true` too. Upload only the display version you have approved; remove private identifiers from that version before adding it to public assets.

The CV button stays hidden until you provide a real file:
```ts
cv: { path: '/documents/suraj-rawat-cv.pdf', filename: 'suraj-rawat-cv.pdf', displayApproved: true }
```

## Contact and links

Set `email`, `github`, `linkedin`, and optional `professionalLinks` only to details you approve for public display. There is no contact form. A supplied valid email becomes a mailto link, which uses the visitor’s email app; it does not claim the message was delivered.

About Me, Skills, Projects, Qualifications, and Contact navigation links open new tabs with `target="_blank"` and `rel="noopener noreferrer"`. Their arrow indicators and accessible text explain this. Home and the logo stay in the current tab. Project-detail links and within-page contents links use the current tab. Supplied external links open new tabs.

## Finish the preview

Keep `previewMode: true` while reviewing missing material. Once the content is ready, set it to false: unconfirmed projects, credentials, and skills are then excluded. Review remaining mandatory-page empty states before sharing. The initial preview disables search indexing in `app/layout.tsx`; enable indexing there only when the portfolio is ready and the site’s audience is deliberately made public.

Do not place private files, identifiers, secrets, or unused private originals under `public/`. Everything in that folder is a site asset.

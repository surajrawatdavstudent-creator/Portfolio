# Portfolio checks — 11 September 2026

## Passed

- TypeScript validation (`tsc --noEmit`).
- Production build through the Sites build helper.
- Browser checks of all six main pages at desktop width, including correct headings, unique titles, no horizontal overflow, and consistent navigation.
- Actual clicks on About Me, Skills, Projects, Qualifications, and Contact opened five distinct browser tabs at the correct URLs. Each had `target="_blank"` and `rel="noopener noreferrer"` with accessible new-tab text.
- Home navigation from the 404 page returned to `/` in the current tab.
- All four project detail pages opened directly and were refreshed successfully. Each rendered the six grouped sections covering the requested detail fields. Their titles and descriptions matched the selected project.
- Every project contents anchor referenced an existing section. The Results & evidence link was clicked and navigated to `#results`.
- Phone-width checks for all six main pages and a representative project detail page found no horizontal overflow. The homepage was additionally checked at 320, 768, and 1024 pixel frame widths. These were actual CSS viewports inside a temporary browser test frame, not physical devices; scrollbars reduce usable width by 15 pixels.
- Visual inspection of the desktop homepage and phone homepage, project gallery, contact page, and open mobile menu.
- Mobile menu opened by pointer and keyboard. Tab reached a link within the dialog. Escape closed the menu, and focus returned to the Menu trigger after the closing transition. Mobile links had the same new-tab attributes as desktop links.
- Visible focus styling was observed in the mobile menu.
- No empty or `#` placeholder links were found on the homepage. All currently rendered portfolio destinations are among the implemented pages and project routes.
- Contact and qualifications pages render no mailto or download actions while files/details are missing. Optional LinkedIn, achievements, live demos, diagrams, videos, and software-project sections are hidden when empty.
- Content review: no invented project status, measurements, grades, credentials, testimonials, personal address, or phone number. C/C++ and CAD remain omitted pending confirmation.
- Reduced-motion media rules, semantic landmarks, media dimension attributes, natural image proportions, lazy loading, and credential display approval conditions were reviewed in source.
- The temporary viewport test route was removed before the final production build.

## Limits

- Real portrait, project photos, videos, certificates, CV downloads, email links, GitHub links, and live demos could not be checked because approved assets and URLs were not supplied.
- Physical phone/tablet testing, Safari/Firefox testing, full screen-reader testing, 200% text enlargement, and operating-system reduced-motion simulation were not performed.
- Some secondary-page screenshots timed out; those pages were checked through their rendered DOM, headings, and viewport geometry instead.
- A separate shell HTTP crawl could not reach the isolated preview service. Browser page rendering and project refreshes were verified; raw HTTP response status codes were not independently verified by that crawl.
- Final hosted availability is verified through the native deployment status; the cloud QA browser cannot access the private hosted origin directly.

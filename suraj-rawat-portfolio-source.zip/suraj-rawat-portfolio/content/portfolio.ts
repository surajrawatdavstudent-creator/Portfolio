/** Edit public portfolio content here. Null means not supplied. */
export type Media = { src: string; alt: string; width: number; height: number; caption?: string };
export type PublicLink = { label: string; url: string };
export type Project = {
 slug: string; name: string; category: string; summary: string | null;
 status: 'Completed' | 'In Progress' | 'Planned' | null;
 confirmed: boolean; featured: boolean; tags: string[]; photo: Media | null;
 overview: string | null; goal: string | null; components: string[]; software: string[];
 operation: string | null; diagram: Media | null; contribution: string | null;
 challenges: string | null; results: string | null; evidence: PublicLink[];
 learning: string | null; improvements: string | null; gallery: Media[];
 video: {src: string; poster?: string; caption: string} | null;
 repository: string | null; liveDemo: string | null;
 tutorial: { title: string; url: string; adaptation: string } | null;
};
export type Skill = { name: string; state: 'Used' | 'Learning' | 'To confirm'; example: string | null; projectSlug?: string };
export type Credential = { title: string; issuer: string; date: string | null; confirmed: boolean; preview: Media | null; verification: string | null; displayApproved: boolean };
const draftProject = (slug: string, name: string, category: string, featured = false): Project => ({
 slug, name, category, featured, confirmed: false, summary: null, status: null,
 tags: [], photo: null, overview: null, goal: null, components: [], software: [], operation: null,
 diagram: null, contribution: null, challenges: null, results: null, evidence: [], learning: null,
 improvements: null, gallery: [], video: null, repository: null, liveDemo: null, tutorial: null,
});
const skillsToConfirm = (names: string[]): Skill[] => names.map(name => ({name, state: 'To confirm', example: null}));

export const portfolio = {
 previewMode: true,
 name: 'Suraj Rawat', initials: 'SR', role: 'Student & aspiring engineer',
 headline: 'Exploring Robotics, Mechatronics & Embedded Systems.',
 headlineAccent: 'Embedded Systems.',
 introduction: 'I’m a student interested in how code, electronics, and mechanical systems work together. I’m learning through practical hardware and programming projects, one build at a time.',
 portrait: null as Media | null,
 email: null as string | null, github: null as string | null, linkedin: null as string | null,
 professionalLinks: [] as PublicLink[],
 cv: null as {path: string; filename: string; displayApproved: boolean} | null,
 interests: [
  {name: 'Robotics', description: 'Bringing sensing, movement, and code together.'},
  {name: 'Mechatronics', description: 'Exploring the connection between mechanics and electronics.'},
  {name: 'Automation', description: 'Understanding how systems respond and perform tasks.'},
  {name: 'Embedded systems', description: 'Learning how software interacts with the physical world.'},
 ],
 about: {
  introduction: 'I’m Suraj, a student and aspiring engineer with an interest in robotics, mechatronics, automation, and embedded systems.',
  paragraphs: [
   'I’m learning through practical hardware and programming projects. Building, testing, troubleshooting, and improving a project are all part of that process.',
   'This portfolio is a place to document that learning: the idea behind each project, how it works, the problems I encounter, and what I learn along the way.',
  ],
  motivation: null as string | null,
  priorities: [] as string[],
  future: 'I want to keep exploring robotics, automation, and embedded systems as I work toward studying engineering.',
  process: [
   {title: 'Build', text: 'Turn an idea into a hardware or programming project.'},
   {title: 'Test', text: 'Observe what happens and compare it with the intended behavior.'},
   {title: 'Troubleshoot', text: 'Work through wiring, code, and unexpected behavior.'},
   {title: 'Improve', text: 'Refine the project and document what changed.'},
  ],
 },
 skillCategories: [
  {name: 'Programming', description: 'Writing the logic behind a project.', skills: skillsToConfirm(['Python'])},
  {name: 'Hardware & embedded systems', description: 'Connecting software to physical components.', skills: skillsToConfirm(['Arduino', 'ESP32', 'Sensors', 'Breadboard prototyping'])},
  {name: 'Tools', description: 'Organizing code and the development environment.', skills: skillsToConfirm(['Git', 'GitHub', 'Linux'])},
  {name: 'Practical skills', description: 'The hands-on work that supports a build.', skills: skillsToConfirm(['Circuit wiring', 'Debugging', 'Project documentation', 'Working with APIs'])},
 ],
 projects: [
  draftProject('ultrasonic-distance-measurement', 'Arduino ultrasonic distance measurement', 'Sensors & measurement', true),
  draftProject('line-following-robot', 'Line-following robot', 'Robotics', true),
  draftProject('esp32-stock-price-display', 'ESP32 real-time stock-price display', 'Embedded systems', true),
  draftProject('motion-detection-system', 'Motion-detection system', 'Sensing & automation'),
 ] as Project[],
 softwareProjects: [] as {name: string; description: string; links: PublicLink[]}[],
 education: [] as {period: string; title: string; institution: string; description: string; grade?: string}[],
 certifications: [
  {title: 'Python for Everybody', issuer: 'University of Michigan', date: null, confirmed: false, preview: null, verification: null, displayApproved: false},
  {title: 'Introduction to Git and GitHub', issuer: 'Google', date: null, confirmed: false, preview: null, verification: null, displayApproved: false},
  {title: 'Prompt Engineering', issuer: 'Vanderbilt University', date: null, confirmed: false, preview: null, verification: null, displayApproved: false},
 ] as Credential[],
 achievements: [] as {title: string; description: string; evidence?: string}[],
 copy: {
  homeEyebrow: 'A student’s engineering notebook',
  projectsIntro: 'The ideas, experiments, and lessons behind my hardware and programming projects.',
  projectPreview: 'These are proposed project entries. Descriptions, build status, and evidence are awaiting confirmation.',
  skillsIntro: 'An honest view of the tools I use, the skills I’m developing, and where I apply them.',
  skillsPreview: 'The skills below were listed for this portfolio. My experience and application examples still need confirmation.',
  qualificationsIntro: 'My education and learning beyond the classroom, with supporting credentials when available.',
  contactIntro: 'I’d be glad to hear from people interested in my projects, learning opportunities, or collaborations.',
  contactEmpty: 'My public contact details will appear here once they have been provided.',
  portraitPlaceholder: 'Portrait placeholder', photoPlaceholder: 'Project photo placeholder',
  projectSummaryPlaceholder: 'Project description and personal contribution to be added.',
  githubPlaceholder: 'GitHub link to be added',
  footer: 'Learning through building, testing, and improving.',
 },
};
export function visibleProjects() { return portfolio.projects.filter(p => portfolio.previewMode || p.confirmed); }
export function safeUrl(value: string | null | undefined): string | undefined {
 if (!value) return undefined;
 if (/^\/(?!\/)/.test(value)) return value;
 try { const url = new URL(value); return url.protocol === 'https:' || url.protocol === 'http:' ? value : undefined; } catch { return undefined; }
}
